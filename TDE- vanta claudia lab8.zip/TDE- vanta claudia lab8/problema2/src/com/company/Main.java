package com.company;

class Path {
    private static final int M = 4;
    private static final int N = 4;
    private static final int O = 4;

    private static boolean isSafe(int mat[][][], int visited[][][], int x, int y,int z) {
        return !(mat[x][y][z] == 0 || visited[x][y][z] != 0);
    }

    private static boolean isValid(int x, int y, int z) {
        return (x < M && y < N && z < O && x >= 0 && y >= 0 && z>=0);
    }


    public static int path(int mat[][][], int visited[][][],
                           int i, int j,int k, int x, int y,int z, int min_dist, int dist) {
        if (i == x && j == y && z == k) {
            return Integer.min(dist, min_dist);
        }

        visited[i][j][k] = 1;

        if (isValid(i + 1, j,k) && isSafe(mat, visited, i + 1, j,k)) {

            min_dist = path(mat, visited, i + 1, j,k, x, y,z, min_dist, dist + 1);
        }

        if (isValid(i, j + 1,k) && isSafe(mat, visited, i, j + 1,k)) {

            min_dist = path(mat, visited, i, j + 1,k, x, y,z, min_dist, dist + 1);
        }
        if (isValid(i, j ,k+1) && isSafe(mat, visited, i, j ,k+1)) {

            min_dist = path(mat, visited, i, j ,k+1, x, y,z, min_dist, dist + 1);
        }
 
        if (isValid(i - 1, j,k) && isSafe(mat, visited, i - 1, j,k)) {

            min_dist = path(mat, visited, i - 1, j,k, x, y,z, min_dist, dist + 1);
        }

        if (isValid(i, j - 1,k) && isSafe(mat, visited, i, j - 1,k)) {

            min_dist = path(mat, visited, i, j - 1,k, x, y,z, min_dist, dist + 1);
        }
        if (isValid(i, j ,k-1) && isSafe(mat, visited, i, j ,k-1)) {

            min_dist = path(mat, visited, i, j ,k-1, x, y,z, min_dist, dist + 1);
        }

        visited[i][j][k] = 0;

        return min_dist;
    }

    public static void main(String[] args) {
        int mat[][][] =
                {       {
                                {1, 1, 1, 1},
                                {0, 1, 1, 1},
                                {0, 0, 1, 0},
                                {1, 0, 1, 1},
                        },
                        {
                                {1, 1, 1, 1},
                                {0, 1, 1, 1},
                                {0, 0, 1, 0},
                                {1, 0, 1, 1},
                        },
                        {
                                {1, 1, 1, 1},
                                {0, 1, 1, 1},
                                {0, 0, 1, 0},
                                {1, 0, 1, 1},
                        },
                        {
                                {1, 1, 1, 1},
                                {0, 1, 1, 1},
                                {0, 0, 1, 0},
                                {1, 0, 1, 1},
                        }
                };

        int[][][] visited = new int[M][N][O];

        int min_dist = path(mat, visited, 0, 0,0, 3, 3,3, Integer.MAX_VALUE, 0);

        for (int i = 0; i < mat.length; i++)
        {
            for (int j = 0; j < mat[i].length; j++){
                for (int k = 0; k < mat[i][j].length; k++)

                System.out.print(mat[i][j][k]+"    ");
            System.out.println("");}
        System.out.println("");}



        if (min_dist != Integer.MAX_VALUE) {
            System.out.println("Lungimea celui mai scurt drum este:  " + min_dist);
        } else {
            System.out.println("Nu am putut ajunge la destinatie! ");
        }
    }
}