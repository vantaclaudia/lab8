package com.company;

import java.util.Scanner;

class Partition
{
    static void printArray(int p[], int n)
    {
        for (int i = 0; i < n; i++)
            System.out.print(p[i]+" ");
        System.out.println();
    }

    static void printAllUniqueParts(int n)
    {
        int[] p = new int[n];
        int k = 0;
        p[k] = n;

        while (true)
        {
            printArray(p, k+1);

            int rem_val = 0;
            while (k >= 0 && p[k] == 1)
            {
                rem_val += p[k];
                k--;
            }

            if (k < 0)  return;

            p[k]--;
            rem_val++;

            while (rem_val > p[k])
            {
                p[k+1] = p[k];
                rem_val = rem_val - p[k];
                k++;
            }

            p[k+1] = rem_val;
            k++;
        }
    }

    public static void main (String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduceti numarul dorit: \n");
        int n = sc.nextInt();
        System.out.println("Partitiile acestui numar sunt: \n" + n);
        printAllUniqueParts(n);

    }
}
